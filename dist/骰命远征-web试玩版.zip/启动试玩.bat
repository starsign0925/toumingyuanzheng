@echo off
setlocal
set ELECTRON_RUN_AS_NODE=1
rem 需要本机安装 Cocos Creator 3.8.8；如路径不同请改下面这行
set CC=D:\cocos\Creator\3.8.8\CocosCreator.exe
start "" http://localhost:8787
"%CC%" "%~dp0serve.js" "%~dp0web" 8787
